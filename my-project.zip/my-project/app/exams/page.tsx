'use client';

import { useState } from 'react';
import { INITIAL_EXAMS } from '@/lib/mock-data';
import { Exam } from '@/types';
import { Plus, Upload, Trash2, Calendar, Clock, MapPin, AlertCircle, FileText } from 'lucide-react';
import { getCountdownStatus } from '@/lib/utils';

export default function ExamsPage() {
  const [exams, setExams] = useState<Exam[]>(INITIAL_EXAMS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    subjectName: '',
    subjectCode: '',
    examDate: '',
    examTime: '',
    venue: '',
    difficulty: 'moderate' as 'easy' | 'moderate' | 'hard',
    notes: '',
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subjectName || !formData.examDate) return;

    const newExam: Exam = {
      id: `exam-${Date.now()}`,
      subjectName: formData.subjectName,
      subjectCode: formData.subjectCode || 'GEN-100',
      examDate: formData.examDate,
      examTime: formData.examTime || '09:30',
      venue: formData.venue || 'Main Examination Block',
      difficulty: formData.difficulty,
      notes: formData.notes,
      materials: [],
      topics: [],
    };

    setExams([newExam, ...exams]);
    setShowAddModal(false);
    setFormData({ subjectName: '', subjectCode: '', examDate: '', examTime: '', venue: '', difficulty: 'moderate', notes: '' });
  };

  const handleDelete = (id: string) => {
    setExams(exams.filter((ex) => ex.id !== id));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pt-6 px-4 md:px-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Exam Management</h2>
          <p className="text-sm text-muted-foreground">Track timetable, set venues, and monitor remaining countdowns.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowUploadModal(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-xl border border-border bg-card hover:bg-muted transition-all"
          >
            <Upload className="w-3.5 h-3.5" /> Upload Timetable PDF/Img
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 transition-all shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" /> Add Exam
          </button>
        </div>
      </div>

      {/* Exam Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {exams.map((exam) => {
          const status = getCountdownStatus(exam.examDate, exam.examTime);
          return (
            <div key={exam.id} className="p-5 rounded-2xl border border-border bg-card shadow-sm flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-start gap-2">
                  <div>
                    <span className="text-[11px] font-mono text-muted-foreground">{exam.subjectCode}</span>
                    <h3 className="text-base font-bold">{exam.subjectName}</h3>
                  </div>
                  <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${
                    status.daysLeft <= 2
                      ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/40 border border-rose-200'
                      : 'bg-secondary text-secondary-foreground'
                  }`}>
                    {status.label}
                  </span>
                </div>

                <div className="text-xs text-muted-foreground space-y-1 pt-1">
                  <p className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> {exam.examDate}</p>
                  <p className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> {exam.examTime}</p>
                  <p className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> {exam.venue}</p>
                </div>

                {exam.notes && (
                  <p className="text-xs bg-muted/40 p-2.5 rounded-lg border border-border text-muted-foreground">
                    {exam.notes}
                  </p>
                )}
              </div>

              <div className="flex justify-between items-center pt-3 border-t border-border">
                <span className="text-xs text-muted-foreground">
                  {exam.topics.length} topics • {exam.materials.length} files
                </span>
                <button
                  onClick={() => handleDelete(exam.id)}
                  className="text-xs text-rose-500 hover:text-rose-700 p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Exam Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl p-6 max-w-md w-full shadow-lg space-y-4">
            <h3 className="text-lg font-bold">Add Examination</h3>
            <form onSubmit={handleCreate} className="space-y-3 text-xs">
              <div>
                <label className="font-medium text-foreground">Subject Name</label>
                <input
                  type="text"
                  required
                  value={formData.subjectName}
                  onChange={(e) => setFormData({ ...formData, subjectName: e.target.value })}
                  placeholder="e.g., Computer Networks"
                  className="w-full mt-1 px-3 py-2 rounded-xl border border-border bg-background focus:outline-primary"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-medium text-foreground">Subject Code</label>
                  <input
                    type="text"
                    value={formData.subjectCode}
                    onChange={(e) => setFormData({ ...formData, subjectCode: e.target.value })}
                    placeholder="23CS502"
                    className="w-full mt-1 px-3 py-2 rounded-xl border border-border bg-background focus:outline-primary"
                  />
                </div>
                <div>
                  <label className="font-medium text-foreground">Difficulty</label>
                  <select
                    value={formData.difficulty}
                    onChange={(e) => setFormData({ ...formData, difficulty: e.target.value as any })}
                    className="w-full mt-1 px-3 py-2 rounded-xl border border-border bg-background focus:outline-primary"
                  >
                    <option value="easy">Easy</option>
                    <option value="moderate">Moderate</option>
                    <option value="hard">Hard</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-medium text-foreground">Date</label>
                  <input
                    type="date"
                    required
                    value={formData.examDate}
                    onChange={(e) => setFormData({ ...formData, examDate: e.target.value })}
                    className="w-full mt-1 px-3 py-2 rounded-xl border border-border bg-background focus:outline-primary"
                  />
                </div>
                <div>
                  <label className="font-medium text-foreground">Time</label>
                  <input
                    type="time"
                    value={formData.examTime}
                    onChange={(e) => setFormData({ ...formData, examTime: e.target.value })}
                    className="w-full mt-1 px-3 py-2 rounded-xl border border-border bg-background focus:outline-primary"
                  />
                </div>
              </div>
              <div>
                <label className="font-medium text-foreground">Venue</label>
                <input
                  type="text"
                  value={formData.venue}
                  onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                  placeholder="Exam Hall 3"
                  className="w-full mt-1 px-3 py-2 rounded-xl border border-border bg-background focus:outline-primary"
                />
              </div>
              <div>
                <label className="font-medium text-foreground">Notes</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Important chapters, reference links..."
                  className="w-full mt-1 px-3 py-2 rounded-xl border border-border bg-background focus:outline-primary"
                  rows={2}
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-border bg-background hover:bg-muted"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-semibold"
                >
                  Save Exam
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upload OCR Mock Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl p-6 max-w-md w-full shadow-lg space-y-4">
            <h3 className="text-lg font-bold">Upload Timetable Document</h3>
            <p className="text-xs text-muted-foreground">
              ExamFlow scans your timetable PDF or photo, extracts subjects, dates, and times, and prompts for your verification before saving.
            </p>

            <div className="border-2 border-dashed border-border rounded-xl p-6 text-center space-y-2 hover:bg-muted/20 cursor-pointer">
              <FileText className="w-8 h-8 mx-auto text-muted-foreground" />
              <p className="text-xs font-semibold">Click or drag timetable image/PDF</p>
              <p className="text-[10px] text-muted-foreground">Supports PDF, PNG, JPG</p>
            </div>

            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl text-[11px] text-amber-800 dark:text-amber-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>Extracted dates can always be manually modified before committing to your calendar.</span>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-border">
              <button
                type="button"
                onClick={() => setShowUploadModal(false)}
                className="px-4 py-2 rounded-xl border border-border bg-background text-xs hover:bg-muted"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
