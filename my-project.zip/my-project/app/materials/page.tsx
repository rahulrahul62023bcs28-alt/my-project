'use client';

import { useState } from 'react';
import { INITIAL_EXAMS } from '@/lib/mock-data';
import { BookOpen, Upload, FileText, CheckCircle, Tag, Layers } from 'lucide-react';

export default function MaterialsPage() {
  const [selectedExamId, setSelectedExamId] = useState('exam-1');
  const [exams, setExams] = useState(INITIAL_EXAMS);

  const activeExam = exams.find((e) => e.id === selectedExamId) || exams[0];

  const handleSimulateUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const newMaterial = {
        id: `m-${Date.now()}`,
        fileName: file.name,
        fileType: 'pdf' as const,
        sizeBytes: file.size || 2048000,
        uploadedAt: new Date().toISOString().split('T')[0],
      };

      setExams((prev) =>
        prev.map((ex) =>
          ex.id === selectedExamId
            ? { ...ex, materials: [...ex.materials, newMaterial] }
            : ex
        )
      );
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pt-6 px-4 md:px-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Study Materials & Topics</h2>
          <p className="text-sm text-muted-foreground">Upload course presentations, syllabi, and PDFs to extract structured topics.</p>
        </div>
        <div>
          <select
            value={selectedExamId}
            onChange={(e) => setSelectedExamId(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-border bg-card font-medium"
          >
            {exams.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.subjectName}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Upload & File List */}
        <div className="space-y-4">
          <div className="p-6 rounded-2xl border-2 border-dashed border-border bg-card text-center hover:bg-muted/10 transition-colors">
            <Upload className="w-8 h-8 mx-auto text-primary mb-2" />
            <p className="text-xs font-bold">Upload Course Materials</p>
            <p className="text-[11px] text-muted-foreground mb-3">Accepts PDF, PPT, PPTX, DOCX</p>
            <label className="cursor-pointer inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 shadow-sm">
              <span>Select File</span>
              <input type="file" onChange={handleSimulateUpload} className="hidden" accept=".pdf,.pptx,.ppt,.docx" />
            </label>
          </div>

          <div className="p-5 rounded-2xl border border-border bg-card space-y-3">
            <h4 className="text-xs font-bold text-foreground flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-primary" /> Associated Files ({activeExam.materials.length})
            </h4>
            <div className="space-y-2">
              {activeExam.materials.map((mat) => (
                <div key={mat.id} className="p-3 rounded-xl border border-border bg-background flex justify-between items-center">
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs font-semibold">{mat.fileName}</p>
                      <p className="text-[10px] text-muted-foreground">{(mat.sizeBytes / (1024 * 1024)).toFixed(2)} MB • {mat.uploadedAt}</p>
                    </div>
                  </div>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-muted text-muted-foreground">
                    {mat.fileType}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Extracted Topic Hierarchy */}
        <div className="p-5 rounded-2xl border border-border bg-card space-y-4">
          <div className="flex justify-between items-center border-b border-border pb-3">
            <div>
              <h4 className="text-sm font-bold flex items-center gap-2">
                <Layers className="w-4 h-4 text-primary" /> Extracted Portions & Priorities
              </h4>
              <p className="text-xs text-muted-foreground">Identified concepts from uploaded lecture notes</p>
            </div>
            <span className="text-[11px] font-mono text-muted-foreground">
              {activeExam.topics.length} topics
            </span>
          </div>

          <div className="space-y-2.5">
            {activeExam.topics.map((t) => (
              <div key={t.id} className="p-3 rounded-xl border border-border bg-background flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-secondary text-secondary-foreground">
                      {t.unit}
                    </span>
                    <p className="text-xs font-semibold">{t.name}</p>
                  </div>
                  <p className="text-[10px] text-muted-foreground">Est. Time: {t.estimatedMinutes} mins</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    t.priority === 'high'
                      ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/40'
                      : t.priority === 'medium'
                      ? 'bg-amber-50 text-amber-600 dark:bg-amber-950/40'
                      : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40'
                  }`}>
                    {t.priority}
                  </span>
                  {t.completed && <CheckCircle className="w-4 h-4 text-emerald-500" />}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
