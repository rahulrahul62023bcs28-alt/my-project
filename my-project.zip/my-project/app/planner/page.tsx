'use client';

import { useState } from 'react';
import { INITIAL_EXAMS, INITIAL_STUDY_PLAN } from '@/lib/mock-data';
import { Sparkles, Clock, RefreshCw, CheckCircle2, Circle, AlertTriangle, Send } from 'lucide-react';
import { StudySessionBlock } from '@/types';

export default function PlannerPage() {
  const [selectedExamId, setSelectedExamId] = useState('exam-1');
  const [availableHours, setAvailableHours] = useState('6');
  const [preference, setPreference] = useState('morning');
  const [schedule, setSchedule] = useState<StudySessionBlock[]>(INITIAL_STUDY_PLAN.schedule);
  const [isGenerating, setIsGenerating] = useState(false);
  const [missedAlert, setMissedAlert] = useState(false);

  // Chatbot State
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState([
    { role: 'assistant', text: 'Hi! I am your ExamFlow AI Study Assistant. Ask me how to prioritize your study hours or reschedule missed topics!' }
  ]);

  const activeExam = INITIAL_EXAMS.find((e) => e.id === selectedExamId) || INITIAL_EXAMS[0];

  const handleGeneratePlan = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const generated: StudySessionBlock[] = [
        { id: `gen-1-${Date.now()}`, startTime: '09:00', endTime: '10:00', topicTitle: 'High-Yield Topic: ' + (activeExam.topics[0]?.name || 'Core Fundamentals'), priority: 'high', completed: false },
        { id: `gen-2-${Date.now()}`, startTime: '10:00', endTime: '10:15', topicTitle: '☕ Mind Refreshment Break', isBreak: true, completed: false },
        { id: `gen-3-${Date.now()}`, startTime: '10:15', endTime: '11:45', topicTitle: 'Deep Dive: ' + (activeExam.topics[1]?.name || 'Formulas & Derivations'), priority: 'high', completed: false },
        { id: `gen-4-${Date.now()}`, startTime: '11:45', endTime: '12:30', topicTitle: 'Practice Problems & Previous Papers', priority: 'medium', completed: false },
      ];
      setSchedule(generated);
      setIsGenerating(false);
    }, 700);
  };

  const handleReschedule = () => {
    // Redistribute pending sessions
    const updated = schedule.map((s, idx) => {
      if (!s.completed && !s.isBreak) {
        return { ...s, topicTitle: `[Shifted] ${s.topicTitle}` };
      }
      return s;
    });
    setSchedule(updated);
    setMissedAlert(false);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput;
    setChatMessages((prev) => [...prev, { role: 'user', text: userText }]);
    setChatInput('');

    setTimeout(() => {
      let reply = "Based on your selected exam (" + activeExam.subjectName + "), focus on high-priority topics first and solve previous-year question sets.";
      if (userText.toLowerCase().includes('2 hours')) {
        reply = "With only 2 hours left, prioritize: 1. " + (activeExam.topics[0]?.name || 'Key definitions') + " (50 min), 2. Formula revision (40 min), 3. Quick self-quiz (30 min).";
      }
      setChatMessages((prev) => [...prev, { role: 'assistant', text: reply }]);
    }, 500);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pt-6 px-4 md:px-8">
      {/* Header */}
      <div className="border-b border-border pb-4">
        <h2 className="text-2xl font-bold tracking-tight">AI Study Planner</h2>
        <p className="text-sm text-muted-foreground">Synthesizes portions, available hours, and difficulty to construct an actionable timetable.</p>
      </div>

      {/* Configuration Box */}
      <div className="p-6 rounded-2xl border border-border bg-card shadow-sm space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-semibold">Select Target Examination</label>
            <select
              value={selectedExamId}
              onChange={(e) => setSelectedExamId(e.target.value)}
              className="w-full mt-1.5 px-3 py-2 text-xs rounded-xl border border-border bg-background"
            >
              {INITIAL_EXAMS.map((exam) => (
                <option key={exam.id} value={exam.id}>
                  {exam.subjectName} ({exam.subjectCode})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold">Available Preparation Time</label>
            <select
              value={availableHours}
              onChange={(e) => setAvailableHours(e.target.value)}
              className="w-full mt-1.5 px-3 py-2 text-xs rounded-xl border border-border bg-background"
            >
              <option value="2">2 Hours (Express Revision)</option>
              <option value="4">4 Hours (Targeted Prep)</option>
              <option value="6">6 Hours (Balanced Plan)</option>
              <option value="8">8 Hours (Intensive Plan)</option>
              <option value="12">Full Day (Comprehensive)</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold">Study Habit Preference</label>
            <select
              value={preference}
              onChange={(e) => setPreference(e.target.value)}
              className="w-full mt-1.5 px-3 py-2 text-xs rounded-xl border border-border bg-background"
            >
              <option value="morning">Morning (Early Focus)</option>
              <option value="afternoon">Afternoon</option>
              <option value="evening">Evening / Night Owl</option>
              <option value="flexible">Flexible Blocks</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleGeneratePlan}
          disabled={isGenerating}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-all shadow-sm"
        >
          <Sparkles className="w-4 h-4" />
          {isGenerating ? 'Analyzing Portions & Scheduling...' : 'Generate Personalized Schedule'}
        </button>
      </div>

      {/* Adaptive Re-scheduling Alert */}
      {missedAlert && (
        <div className="p-4 rounded-xl border border-amber-200 bg-amber-50 dark:bg-amber-950/40 dark:border-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <span>You have an uncompleted task from earlier today. Would you like AI to redistribute it?</span>
          </div>
          <button
            onClick={handleReschedule}
            className="px-3 py-1.5 rounded-lg bg-amber-600 text-white font-medium hover:bg-amber-700 transition-colors w-fit"
          >
            Redistribute Remaining Time
          </button>
        </div>
      )}

      {/* Schedule Display */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold">Actionable Timeline</h3>
            <button
              onClick={() => setMissedAlert(true)}
              className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" /> Simulate Missed Block
            </button>
          </div>

          <div className="space-y-3">
            {schedule.map((item) => (
              <div
                key={item.id}
                className={`p-4 rounded-xl border transition-all ${
                  item.isBreak
                    ? 'border-dashed border-border bg-muted/30 text-muted-foreground'
                    : 'border-border bg-card'
                }`}
              >
                <div className="flex justify-between items-start gap-3">
                  <div>
                    <span className="text-[11px] font-mono text-muted-foreground">{item.startTime} – {item.endTime}</span>
                    <h4 className="text-xs font-semibold text-foreground mt-0.5">{item.topicTitle}</h4>
                  </div>
                  {item.priority && (
                    <span className="text-[10px] px-2 py-0.5 rounded font-medium bg-rose-50 text-rose-600 border border-rose-200">
                      {item.priority}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Assistant Sidebar */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-sm flex flex-col h-[480px]">
          <div className="flex items-center gap-2 pb-3 border-b border-border">
            <Sparkles className="w-4 h-4 text-primary" />
            <h4 className="text-xs font-bold">ExamFlow Assistant</h4>
          </div>

          <div className="flex-1 overflow-y-auto space-y-3 py-3 text-xs">
            {chatMessages.map((msg, i) => (
              <div
                key={i}
                className={`p-3 rounded-xl ${
                  msg.role === 'assistant'
                    ? 'bg-muted/60 text-foreground'
                    : 'bg-primary text-primary-foreground ml-4'
                }`}
              >
                {msg.text}
              </div>
            ))}
          </div>

          <form onSubmit={handleSendMessage} className="pt-2 border-t border-border flex gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask: 'I have 2 hours left...'"
              className="flex-1 px-3 py-2 text-xs rounded-xl border border-border bg-background focus:outline-primary"
            />
            <button
              type="submit"
              className="p-2 bg-primary text-primary-foreground rounded-xl hover:bg-primary/90"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
