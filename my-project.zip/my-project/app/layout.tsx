import type { Metadata } from 'next';
import './globals.css';
import { Navigation } from '@/components/navigation/Navbar';

export const metadata: Metadata = {
  title: 'ExamFlow — AI-Powered Exam Scheduler & Study Planner',
  description: 'Smart examination scheduler, syllabus parser, and adaptive preparation planner.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-background text-foreground antialiased min-h-screen">
        <div className="flex">
          <Navigation />
          <main className="flex-1 md:pl-64 min-h-screen pb-20 md:pb-8">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
