'use client';

import { useState } from 'react';
import { Bell, Moon, Sun, Shield, Smartphone } from 'lucide-react';

export default function SettingsPage() {
  const [reminders, setReminders] = useState({
    sevenDays: true,
    threeDays: true,
    oneDay: true,
    examMorning: true,
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6 pt-6 px-4 md:px-8">
      <div className="border-b border-border pb-4">
        <h2 className="text-2xl font-bold tracking-tight">Settings & Notification Preferences</h2>
        <p className="text-sm text-muted-foreground">Configure reminder intervals, notification delivery, and app defaults.</p>
      </div>

      <div className="space-y-6">
        {/* Reminder Settings */}
        <div className="p-6 rounded-2xl border border-border bg-card space-y-4">
          <h3 className="text-sm font-bold flex items-center gap-2">
            <Bell className="w-4 h-4 text-primary" /> Exam Date Reminders
          </h3>
          <p className="text-xs text-muted-foreground">
            ExamFlow provides periodic reminders leading up to your examination date.
          </p>

          <div className="space-y-3 pt-2 text-xs">
            <label className="flex items-center justify-between p-3 rounded-xl border border-border bg-background cursor-pointer">
              <div>
                <p className="font-semibold">7 Days Before</p>
                <p className="text-muted-foreground text-[11px]">Notice to begin material gathering & syllabus mapping</p>
              </div>
              <input
                type="checkbox"
                checked={reminders.sevenDays}
                onChange={(e) => setReminders({ ...reminders, sevenDays: e.target.checked })}
                className="w-4 h-4 text-primary rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl border border-border bg-background cursor-pointer">
              <div>
                <p className="font-semibold">3 Days Before</p>
                <p className="text-muted-foreground text-[11px]">Deep preparation schedule generation prompt</p>
              </div>
              <input
                type="checkbox"
                checked={reminders.threeDays}
                onChange={(e) => setReminders({ ...reminders, threeDays: e.target.checked })}
                className="w-4 h-4 text-primary rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl border border-border bg-background cursor-pointer">
              <div>
                <p className="font-semibold">1 Day Before (Final Sprint)</p>
                <p className="text-muted-foreground text-[11px]">Formula checklist and high-priority topic alert</p>
              </div>
              <input
                type="checkbox"
                checked={reminders.oneDay}
                onChange={(e) => setReminders({ ...reminders, oneDay: e.target.checked })}
                className="w-4 h-4 text-primary rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl border border-border bg-background cursor-pointer">
              <div>
                <p className="font-semibold">Exam Day Morning</p>
                <p className="text-muted-foreground text-[11px]">Venue location and examination time callout</p>
              </div>
              <input
                type="checkbox"
                checked={reminders.examMorning}
                onChange={(e) => setReminders({ ...reminders, examMorning: e.target.checked })}
                className="w-4 h-4 text-primary rounded"
              />
            </label>
          </div>
        </div>

        {/* Database & Architecture Ready */}
        <div className="p-6 rounded-2xl border border-border bg-card space-y-3">
          <h3 className="text-sm font-bold flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-500" /> Architecture Security
          </h3>
          <p className="text-xs text-muted-foreground leading-relaxed">
            All AI API requests are proxied via server-side Next.js route handlers. Secret keys and Supabase service tokens are never exposed to the client.
          </p>
        </div>
      </div>
    </div>
  );
}
