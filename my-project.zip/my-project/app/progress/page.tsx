'use client';

import { useState } from 'react';
import { INITIAL_EXAMS } from '@/lib/mock-data';
import { CheckCircle2, Circle, Zap, ShieldCheck } from 'lucide-react';

export default function ProgressPage() {
  const [selectedExamId, setSelectedExamId] = useState('exam-1');
  const [exams, setExams] = useState(INITIAL_EXAMS);
  const [revisionMode, setRevisionMode] = useState(false);

  const activeExam = exams.find((e) => e.id === selectedExamId) || exams[0];

  const totalTopics = activeExam.topics.length;
  const completedTopics = activeExam.topics.filter((t) => t.completed).length;
  const readinessPercent = totalTopics > 0 ? Math.round((completedTopics / totalTopics) * 100) : 0;

  const toggleTopic = (id: string) => {
    setExams((prev) =>
      prev.map((ex) =>
        ex.id === selectedExamId
          ? {
              ...ex,
              topics: ex.topics.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)),
            }
          : ex
      )
    );
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pt-6 px-4 md:px-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Progress & Readiness</h2>
          <p className="text-sm text-muted-foreground">Monitor topic completion metrics and trigger rapid revision schedules.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setRevisionMode(!revisionMode)}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-all shadow-sm ${
              revisionMode
                ? 'bg-rose-600 text-white'
                : 'border border-border bg-card hover:bg-muted text-foreground'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            {revisionMode ? 'Exit Revision Mode' : 'Quick Revision Mode'}
          </button>
        </div>
      </div>

      {/* Quick Revision Callout */}
      {revisionMode && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-rose-50 to-orange-50 dark:from-rose-950/40 dark:to-orange-950/40 border border-rose-200 dark:border-rose-900 space-y-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-rose-600 text-white">LAST-MINUTE 60-MIN SPRINT</span>
            <span className="text-xs font-medium text-rose-900 dark:text-rose-200">{activeExam.subjectName}</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-2.5 bg-background/80 rounded-xl border border-rose-200 dark:border-rose-800">
              <p className="font-mono text-muted-foreground text-[10px]">20 min</p>
              <p className="font-bold">Key Formulas & Theorems</p>
            </div>
            <div className="p-2.5 bg-background/80 rounded-xl border border-rose-200 dark:border-rose-800">
              <p className="font-mono text-muted-foreground text-[10px]">15 min</p>
              <p className="font-bold">High Priority Subtopics</p>
            </div>
            <div className="p-2.5 bg-background/80 rounded-xl border border-rose-200 dark:border-rose-800">
              <p className="font-mono text-muted-foreground text-[10px]">15 min</p>
              <p className="font-bold">Past Exam Frequent Questions</p>
            </div>
            <div className="p-2.5 bg-background/80 rounded-xl border border-rose-200 dark:border-rose-800">
              <p className="font-mono text-muted-foreground text-[10px]">10 min</p>
              <p className="font-bold">Rapid Flashcard Review</p>
            </div>
          </div>
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl border border-border bg-card space-y-1">
          <p className="text-xs text-muted-foreground">App Readiness Score</p>
          <p className="text-2xl font-bold">{readinessPercent}%</p>
          <p className="text-[10px] text-muted-foreground">Calculated from covered syllabus items</p>
        </div>
        <div className="p-5 rounded-2xl border border-border bg-card space-y-1">
          <p className="text-xs text-muted-foreground">Topics Completed</p>
          <p className="text-2xl font-bold">{completedTopics} / {totalTopics}</p>
          <p className="text-[10px] text-muted-foreground">Units 1 through 3</p>
        </div>
        <div className="p-5 rounded-2xl border border-border bg-card space-y-1">
          <p className="text-xs text-muted-foreground">Pending Portions</p>
          <p className="text-2xl font-bold text-rose-500">{totalTopics - completedTopics}</p>
          <p className="text-[10px] text-muted-foreground">Topics requiring revision</p>
        </div>
      </div>

      {/* Interactive Topic Checklist */}
      <div className="p-6 rounded-2xl border border-border bg-card space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-sm font-bold">Preparation Checklist</h3>
          <span className="text-xs text-muted-foreground font-mono">Tap circle to update status</span>
        </div>

        <div className="space-y-2.5">
          {activeExam.topics.map((topic) => (
            <div
              key={topic.id}
              onClick={() => toggleTopic(topic.id)}
              className="p-3.5 rounded-xl border border-border bg-background hover:bg-muted/30 cursor-pointer flex items-center justify-between transition-colors"
            >
              <div className="flex items-center gap-3">
                {topic.completed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                ) : (
                  <Circle className="w-5 h-5 text-muted-foreground shrink-0" />
                )}
                <div>
                  <p className={`text-xs font-semibold ${topic.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                    {topic.name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{topic.unit} • {topic.estimatedMinutes} mins</p>
                </div>
              </div>

              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                topic.priority === 'high' ? 'bg-rose-50 text-rose-600' : 'bg-secondary text-secondary-foreground'
              }`}>
                {topic.priority}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
