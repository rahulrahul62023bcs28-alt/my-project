'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Sparkles, ArrowRight, Clock, MapPin, CheckCircle2, Circle, AlertCircle, BookOpen, Layers } from 'lucide-react';
import { INITIAL_EXAMS, INITIAL_STUDY_PLAN } from '@/lib/mock-data';
import { getCountdownStatus } from '@/lib/utils';

export default function DashboardPage() {
  const [exams] = useState(INITIAL_EXAMS);
  const [studyPlan, setStudyPlan] = useState(INITIAL_STUDY_PLAN);

  const primaryExam = exams[0];
  const totalTopics = primaryExam.topics.length;
  const completedTopics = primaryExam.topics.filter((t) => t.completed).length;
  const progressPercent = Math.round((completedTopics / totalTopics) * 100);

  const countdown = getCountdownStatus(primaryExam.examDate, primaryExam.examTime);

  const toggleTask = (sessionId: string) => {
    setStudyPlan((prev) => ({
      ...prev,
      schedule: prev.schedule.map((session) =>
        session.id === sessionId ? { ...session, completed: !session.completed } : session
      ),
    }));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pt-6 px-4 md:px-8">
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-border pb-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Good day 👋</h2>
          <p className="text-sm text-muted-foreground">Keep your rhythm. Here is your current preparation overview.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 font-medium border border-emerald-200 dark:border-emerald-800">
            System Synchronized
          </span>
        </div>
      </div>

      {/* Hero Card: Next Exam & Countdown */}
      <div className="relative overflow-hidden rounded-2xl border border-border bg-gradient-to-br from-card via-card to-primary/5 p-6 md:p-8 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-full bg-primary/10 text-primary">
              <AlertCircle className="w-3.5 h-3.5" /> Next Examination
            </span>
            <h3 className="text-2xl font-bold text-foreground">{primaryExam.subjectName}</h3>
            <p className="text-sm text-muted-foreground font-mono">{primaryExam.subjectCode} • {primaryExam.venue}</p>
          </div>

          <div className="md:text-right bg-background/80 md:bg-transparent p-4 md:p-0 rounded-xl border md:border-0 border-border">
            <div className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 border border-rose-200 dark:border-rose-900">
              {countdown.label}
            </div>
            <p className="text-xs text-muted-foreground mt-2 flex items-center md:justify-end gap-1 font-medium">
              <Clock className="w-3.5 h-3.5" /> {primaryExam.examDate} • {primaryExam.examTime}
            </p>
            <p className="text-xs text-muted-foreground flex items-center md:justify-end gap-1 mt-1">
              <MapPin className="w-3.5 h-3.5" /> {primaryExam.venue}
            </p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-6 pt-5 border-t border-border">
          <div className="flex justify-between items-center text-xs mb-2">
            <span className="text-muted-foreground font-medium">Portion Preparation Readiness</span>
            <span className="font-semibold text-foreground">{progressPercent}% ({completedTopics}/{totalTopics} topics completed)</span>
          </div>
          <div className="w-full bg-secondary h-2.5 rounded-full overflow-hidden">
            <div
              className="bg-primary h-full rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            href="/planner"
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 transition-all shadow-sm"
          >
            <Sparkles className="w-4 h-4" /> AI Study Planner
          </Link>
          <Link
            href="/exams"
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl border border-border bg-background hover:bg-muted transition-all"
          >
            Manage Timetable <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            href="/materials"
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl border border-border bg-background hover:bg-muted transition-all"
          >
            <BookOpen className="w-4 h-4" /> View Materials ({primaryExam.materials.length})
          </Link>
        </div>
      </div>

      {/* Bento Grid: Today's Adaptive Plan & Upcoming Schedule */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Today's Adaptive Schedule */}
        <div className="rounded-2xl border border-border bg-card p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-border pb-3">
            <div>
              <h4 className="font-semibold text-sm">Today&apos;s Adaptive Plan</h4>
              <p className="text-xs text-muted-foreground">Click items to mark them as completed</p>
            </div>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-secondary text-secondary-foreground font-medium">
              6h Session
            </span>
          </div>

          <div className="space-y-2.5">
            {studyPlan.schedule.map((session) => (
              <button
                key={session.id}
                onClick={() => !session.isBreak && toggleTask(session.id)}
                className={`w-full text-left p-3 rounded-xl border flex items-start gap-3 transition-colors ${
                  session.isBreak
                    ? 'border-dashed border-border bg-muted/40 text-muted-foreground cursor-default'
                    : session.completed
                    ? 'border-border bg-muted/30 text-muted-foreground line-through'
                    : 'border-border bg-background hover:bg-muted/50 text-foreground'
                }`}
              >
                {!session.isBreak && (
                  <span className="mt-0.5 text-primary">
                    {session.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Circle className="w-4 h-4" />
                    )}
                  </span>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline gap-2">
                    <p className="text-xs font-semibold truncate">{session.topicTitle}</p>
                    <span className="text-[11px] text-muted-foreground whitespace-nowrap font-mono">
                      {session.startTime} - {session.endTime}
                    </span>
                  </div>
                  {session.priority && (
                    <span
                      className={`inline-block mt-1 text-[10px] px-2 py-0.5 rounded-md font-medium ${
                        session.priority === 'high'
                          ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/50'
                          : 'bg-amber-50 text-amber-600 dark:bg-amber-950/50'
                      }`}
                    >
                      {session.priority} priority
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Upcoming Exam Calendar */}
        <div className="rounded-2xl border border-border bg-card p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-border pb-3">
            <div>
              <h4 className="font-semibold text-sm">Upcoming Timetable</h4>
              <p className="text-xs text-muted-foreground">Synchronized countdown tracker</p>
            </div>
            <Link href="/exams" className="text-xs text-primary hover:underline font-medium">
              View All
            </Link>
          </div>

          <div className="space-y-3">
            {exams.map((exam) => {
              const status = getCountdownStatus(exam.examDate, exam.examTime);
              return (
                <div
                  key={exam.id}
                  className="p-3.5 rounded-xl border border-border bg-background flex justify-between items-center hover:border-primary/40 transition-colors"
                >
                  <div className="space-y-0.5">
                    <h5 className="text-sm font-semibold">{exam.subjectName}</h5>
                    <p className="text-xs text-muted-foreground font-mono">{exam.subjectCode} • {exam.examDate}</p>
                  </div>
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                    status.daysLeft <= 2
                      ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-400 border border-rose-200'
                      : 'bg-secondary text-secondary-foreground'
                  }`}>
                    {status.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="pt-2">
            <Link
              href="/progress"
              className="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl border border-dashed border-border text-xs text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
            >
              <Layers className="w-3.5 h-3.5" /> Check Cumulative Preparation Analytics
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
