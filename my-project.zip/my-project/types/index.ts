export type Priority = 'high' | 'medium' | 'low';

export interface Topic {
  id: string;
  unit: string;
  name: string;
  priority: Priority;
  estimatedMinutes: number;
  completed: boolean;
}

export interface StudyMaterial {
  id: string;
  fileName: string;
  fileType: 'pdf' | 'pptx' | 'docx' | 'txt';
  sizeBytes: number;
  uploadedAt: string;
}

export interface Exam {
  id: string;
  subjectName: string;
  subjectCode: string;
  examDate: string; // YYYY-MM-DD
  examTime: string; // HH:mm
  venue: string;
  difficulty: 'easy' | 'moderate' | 'hard';
  notes?: string;
  materials: StudyMaterial[];
  topics: Topic[];
}

export interface StudySessionBlock {
  id: string;
  startTime: string;
  endTime: string;
  topicId?: string;
  topicTitle: string;
  isBreak?: boolean;
  priority?: Priority;
  completed: boolean;
}

export interface StudyPlan {
  examId: string;
  totalAllocatedHours: number;
  preference: 'morning' | 'afternoon' | 'evening' | 'flexible';
  schedule: StudySessionBlock[];
}

export interface ReminderNotification {
  id: string;
  examId: string;
  title: string;
  message: string;
  daysRemaining: number;
  timestamp: string;
  read: boolean;
}
