# 📚 ExamFlow — AI-Powered Exam Scheduler & Personalized Study Planner

ExamFlow is a modern, mobile-first web application designed for students to manage exam schedules, analyze study materials (PDFs/PPTs), and automatically generate personalized, adaptive preparation timetables.

---

## 🚀 Key Features

1. **Intelligent Dashboard**: Real-time countdowns, immediate upcoming exam alerts, today's schedule checklist, and cumulative preparation progress.
2. **Exam Management**: Timetable organizer with manual entries and timetable document OCR upload scanner.
3. **AI Material Analyzer**: Breaks down lecture PPTs and PDFs into units, chapters, and high-yield topics with priority tagging.
4. **Adaptive Study Planner**: Distributes topics across available study hours (2h, 4h, 6h, full day) with automated rescheduling for missed sessions.
5. **Quick Revision Mode**: 60-minute pre-exam sprints targeting key formulas, high-yield definitions, and previous exam questions.
6. **Mobile-First Responsive Layout**: Bottom bar on phones and expandable sidebar on desktop.

---

## 🛠️ Technology Stack

- **Framework**: [Next.js 14](https://nextjs.org/) (App Router)
- **Language**: [TypeScript](https://www.typescriptlang.org/) (Strict Mode)
- **Styling**: [Tailwind CSS](https://tailwindcss.com/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Animation**: [Motion / Framer Motion](https://www.framer.com/motion/)

---

## 📦 Project Structure

```
ExamFlow/
├── app/
│   ├── layout.tsx         # Responsive root shell with sidebar & mobile bottom bar
│   ├── page.tsx           # Bento-style student dashboard
│   ├── globals.css        # Tailwind theme variables
│   ├── exams/page.tsx     # Timetable management & OCR verification
│   ├── planner/page.tsx   # Adaptive AI study schedule generator & assistant
│   ├── materials/page.tsx # Material upload & portion hierarchy
│   ├── progress/page.tsx  # Readiness metrics & quick 60-min sprint
│   └── settings/page.tsx  # Reminder intervals & preferences
├── components/
│   └── navigation/
│       └── Navbar.tsx     # Desktop sidebar + mobile bottom nav
├── lib/
│   ├── mock-data.ts       # Mock dataset
│   └── utils.ts           # Countdown and Tailwind merge helpers
├── types/
│   └── index.ts           # Type definitions (Exam, Topic, StudyPlan)
├── .env.example           # Environment variables placeholder
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── README.md
```

---

## 💻 Getting Started

### 1. Prerequisites
Ensure you have **Node.js 18.17+** installed.

### 2. Installation
```bash
npm install
```

### 3. Environment Configuration
Copy the template environment file:
```bash
cp .env.example .env.local
```

### 4. Run Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 5. Production Build
```bash
npm run build
npm run start
```
