import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getCountdownStatus(targetDate: string, targetTime: string): { label: string; daysLeft: number; isPast: boolean } {
  const examDateTime = new Date(`${targetDate}T${targetTime}:00`);
  const now = new Date();
  const diffTime = examDateTime.getTime() - now.getTime();
  const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffTime < 0) return { label: 'Completed', daysLeft, isPast: true };
  if (daysLeft === 0) return { label: 'Today', daysLeft, isPast: false };
  if (daysLeft === 1) return { label: 'Tomorrow', daysLeft, isPast: false };
  return { label: `${daysLeft} days left`, daysLeft, isPast: false };
}
