import { Exam, StudyPlan } from '@/types';

export const INITIAL_EXAMS: Exam[] = [
  {
    id: 'exam-1',
    subjectName: 'Database Management Systems',
    subjectCode: 'CS501',
    examDate: '2026-09-20',
    examTime: '09:30',
    venue: 'Exam Hall B, Block 3',
    difficulty: 'hard',
    notes: 'Focus on Normalization algorithms and Relational Algebra proofs.',
    materials: [
      { id: 'm-1', fileName: 'Unit_1_Architecture.pdf', fileType: 'pdf', sizeBytes: 2450000, uploadedAt: '2026-09-10' },
      { id: 'm-2', fileName: 'Unit_2_SQL_Transactions.pptx', fileType: 'pptx', sizeBytes: 5200000, uploadedAt: '2026-09-11' },
      { id: 'm-3', fileName: 'Important_Questions_DBMS.pdf', fileType: 'pdf', sizeBytes: 1100000, uploadedAt: '2026-09-12' }
    ],
    topics: [
      { id: 't-1', unit: 'Unit 1', name: 'Database Architecture & Data Models', priority: 'medium', estimatedMinutes: 45, completed: true },
      { id: 't-2', unit: 'Unit 1', name: 'ER Model & Constraints Mapping', priority: 'high', estimatedMinutes: 60, completed: true },
      { id: 't-3', unit: 'Unit 2', name: 'Advanced SQL & Nested Subqueries', priority: 'high', estimatedMinutes: 75, completed: true },
      { id: 't-4', unit: 'Unit 2', name: 'Functional Dependency & Normalization', priority: 'high', estimatedMinutes: 90, completed: false },
      { id: 't-5', unit: 'Unit 3', name: 'Transactions & ACID Properties', priority: 'high', estimatedMinutes: 60, completed: false },
      { id: 't-6', unit: 'Unit 3', name: 'Concurrency Control & Two-Phase Locking', priority: 'medium', estimatedMinutes: 50, completed: false }
    ]
  },
  {
    id: 'exam-2',
    subjectName: 'Computer Networks',
    subjectCode: 'CS502',
    examDate: '2026-09-24',
    examTime: '14:00',
    venue: 'Network Lab / Hall 4',
    difficulty: 'moderate',
    notes: 'Cover ALOHA, CSMA/CD, IPv4 addressing, and routing algorithms.',
    materials: [
      { id: 'm-4', fileName: 'CN_Portions_Syllabus.pdf', fileType: 'pdf', sizeBytes: 1800000, uploadedAt: '2026-09-12' },
      { id: 'm-5', fileName: 'Unit_3_Routing_OSPF.pptx', fileType: 'pptx', sizeBytes: 4100000, uploadedAt: '2026-09-14' }
    ],
    topics: [
      { id: 't-7', unit: 'Unit 1', name: 'OSI vs TCP/IP Architecture', priority: 'low', estimatedMinutes: 30, completed: true },
      { id: 't-8', unit: 'Unit 2', name: 'CSMA/CD & Pure/Slotted ALOHA', priority: 'high', estimatedMinutes: 60, completed: false },
      { id: 't-9', unit: 'Unit 3', name: 'IPv4 Subnetting & CIDR Calculation', priority: 'high', estimatedMinutes: 90, completed: false },
      { id: 't-10', unit: 'Unit 3', name: 'Distance Vector & Link State Routing', priority: 'medium', estimatedMinutes: 60, completed: false }
    ]
  },
  {
    id: 'exam-3',
    subjectName: 'Operating Systems',
    subjectCode: 'CS503',
    examDate: '2026-09-28',
    examTime: '09:30',
    venue: 'Auditorium Hall A',
    difficulty: 'hard',
    notes: 'CPU scheduling, paging/segmentation, Semaphores and Monitors.',
    materials: [
      { id: 'm-6', fileName: 'OS_Synchronization_Semaphores.pdf', fileType: 'pdf', sizeBytes: 3200000, uploadedAt: '2026-09-13' }
    ],
    topics: [
      { id: 't-11', unit: 'Unit 1', name: 'Process Synchronization & Semaphores', priority: 'high', estimatedMinutes: 75, completed: false },
      { id: 't-12', unit: 'Unit 2', name: 'Virtual Memory & Page Replacement', priority: 'high', estimatedMinutes: 60, completed: false }
    ]
  }
];

export const INITIAL_STUDY_PLAN: StudyPlan = {
  examId: 'exam-1',
  totalAllocatedHours: 6,
  preference: 'morning',
  schedule: [
    { id: 's-1', startTime: '09:00', endTime: '10:15', topicId: 't-4', topicTitle: 'Normalization (1NF, 2NF, 3NF, BCNF)', priority: 'high', completed: false },
    { id: 's-2', startTime: '10:15', endTime: '10:30', topicTitle: '☕ Quick Break & Hydration', isBreak: true, completed: false },
    { id: 's-3', startTime: '10:30', endTime: '11:45', topicId: 't-5', topicTitle: 'Transactions & ACID Properties', priority: 'high', completed: false },
    { id: 's-4', startTime: '11:45', endTime: '12:45', topicId: 't-6', topicTitle: 'Concurrency Control & 2PL', priority: 'medium', completed: false },
    { id: 's-5', startTime: '12:45', endTime: '13:45', topicTitle: '🍱 Lunch & Rest', isBreak: true, completed: false },
    { id: 's-6', startTime: '13:45', endTime: '15:00', topicTitle: 'Previous Year Question Analysis & Revision', priority: 'high', completed: false }
  ]
};
